﻿cls

# prelozi textovej soubor v cestine ( kodovani UTF8 ) do souboru Wav

Add-Type -AssemblyName System.Speech
$synth = New-Object -TypeName System.Speech.Synthesis.SpeechSynthesizer

#$synth.GetInstalledVoices() | Select-Object -ExpandProperty VoiceInfo # dela vypis hlasu
$hlasy = $synth.GetInstalledVoices() | Select-Object -ExpandProperty VoiceInfo # dela vypis hlasu
$d_hlasy = $hlasy.Length -1
#echo $d_hlasy


for ($aa = 0; $aa -le $d_hlasy -1; $aa++) {
$out_1 = ""
$out_1 += [string] $aa
$out_1 += " - "
$out_1 += $hlasy[$aa].Name
$out_1 += " - "
$out_1 += $hlasy[$aa].Culture.Name
echo $out_1
#echo "$aa - $hlas[$aa] - $narodnost[$aa]"
}

$out_2 = "vyber hlas 0-"
$out_2 += [string] $d_hlasy
$out_2 += " ?"
[int] $volba = Read-Host -Prompt $out_2
echo $volba

$synth.SelectVoice($hlasy[$volba].Name)


# cesta k soubu z ceskym textem (UTF8)
$input_text = "text.txt" # nazev, pripadne cela cesta k soubor z ceskym textem

# Načtení textu ze souboru
$text = Get-Content $input_text -Encoding UTF8 # UTF8 je pro cestinu
Write-Host -ForegroundColor yellow $text # melo by se zobrazit joko cesky text z diakritikou ( paklize ne tak je chyba a *.wav bude rikat kraviny )


$name_wav = "audio" # nazev vystupniho souboru wav

#$synth = New-Object -TypeName System.Speech.Synthesis.SpeechSynthesizer
#$synth.SelectVoice("Microsoft Jakub") # vybrat z vypisu hlas

# Nastavení hlasitosti a rychlosti
$synth.Volume = 100 # hlasitost 0-100 
$synth.Rate = 0 # -10 az 10 ( 0 = normalni rychlost mluveni )

#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(8000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono)
$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Stereo)
#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono)

$synth.SetOutputToWaveFile("$name_wav.wav", $streamFormat)

#$synth.SetOutputToWaveFile("C:\Users\DELL\Documents\ps1\Sound-Speech-PlayWav\speech_to_wave\$name.wav", $streamFormat )
$synth.SetOutputToWaveFile("$name_wav.wav", $streamFormat )
$synth.Speak($text)

$synth.Dispose() # uzavreni streamu

echo "text byl ulozen do souboru '$input_text'"

sleep 10

