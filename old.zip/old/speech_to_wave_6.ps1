﻿cls

Add-Type -AssemblyName System.Speech

# vypise vsechny nainstalovane a odemknutych hlasu
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$synth.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name }
echo "----------------------------"


# Načtení textu ze souboru
$inputFile = "rekni.txt"

#$text = Get-Content $inputFile -Raw
$text = Get-Content $inputFile -Encoding UTF8

#$f = Get-Content -Path "R:\pokus1-convert" -Encoding String
echo $text


$name_wav = "output_1" # nazev vystupniho souboru wav

#$input_text = "Ve Windows 10 jsou některé hlasy předinstalované, jiné je potřeba doinstalovat přes" #, "pondely"

$speak = New-Object -TypeName System.Speech.Synthesis.SpeechSynthesizer
$speak.SelectVoice("Microsoft Jakub") # vybrat z vypisu hlas

# Nastavení hlasitosti a rychlosti
$speak.Volume = 100
$speak.Rate = -10

#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(8000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono)
$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Stereo)
$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono)

$speak.SetOutputToWaveFile("$name_wav.wav", $streamFormat)

#$speak.SetOutputToWaveFile("C:\Users\DELL\Documents\ps1\Sound-Speech-PlayWav\speech_to_wave\$name.wav")
$speak.SetOutputToWaveFile("$name_wav.wav", $streamFormat )
$speak.Speak($text)

$speak.Dispose() # uzavreni streamu

