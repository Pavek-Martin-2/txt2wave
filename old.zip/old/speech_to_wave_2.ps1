﻿cls

Add-Type -AssemblyName System.Speech

$name = "output_1"


$input = "Name One", "Name Two", "Name Tree"


foreach ($name in $input) {
$speak = New-Object -TypeName System.Speech.Synthesis.SpeechSynthesizer

#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]
$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]

#$speak.SetOutputToWaveFile("C:\work\$name.wav", $streamFormat)
echo "$pwd\$name.wav"

#$speak.SetOutputToWaveFile("C:\Users\DELL\Documents\ps1\Sound-Speech-PlayWav\speech_to_wave\$name.wav")
$speak.SetOutputToWaveFile("$PWD\$name.wav")

$speak.Speak($name)
$speak.Dispose()

}




