﻿cls

Add-Type -AssemblyName System.Speech

# vypise vsechny nainstalovane a odemknutych hlasu
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$synth.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name }


# cesta k soubu z ceskym textem (UTF8)
$input_text = "text.txt" # nazev, pripadne cela cesta k soubor z ceskym textem

# Načtení textu ze souboru
$text = Get-Content $input_text -Encoding UTF8 # UTF8 je pro cestinu
 $text # melo by se zobrazit joko cesky text z diakritikou ( paklize ne tak je chyba a *.wav bude rikat kraviny )

$name_wav = "audio" # nazev vystupniho souboru wav

$speak = New-Object -TypeName System.Speech.Synthesis.SpeechSynthesizer
$speak.SelectVoice("Microsoft Jakub") # vybrat z vypisu hlas

# Nastavení hlasitosti a rychlosti
$speak.Volume = 100 # hlasitost 0-100 
$speak.Rate = 0 # -10 az 10 ( 0 = normalni rychlost mluveni )

#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(8000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono)
$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Stereo)
#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono)

$speak.SetOutputToWaveFile("$name_wav.wav", $streamFormat)

#$speak.SetOutputToWaveFile("C:\Users\DELL\Documents\ps1\Sound-Speech-PlayWav\speech_to_wave\$name.wav", $streamFormat )
$speak.SetOutputToWaveFile("$name_wav.wav", $streamFormat )
$speak.Speak($text)

$speak.Dispose() # uzavreni streamu

