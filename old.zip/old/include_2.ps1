﻿cls

# prelozi vsechny nalezene textove soubory v cestine ( kodovani UTF8 ) do souboru Wav pripanne take do mp3

# test jestli program nalezl utilitu "ffmpeg" aby bylo moze vytvaret take souboru *.mp3 ( uspora mista na disku )
Remove-Variable exist_ffmpeg, prog, file_txt, d_file_txt -ErrorAction SilentlyContinue
$exist_ffmpeg = 0

#$prog = "ffmpegXXXX" # testovaci
$prog = "ffmpeg"
if ( Get-Command $prog -ErrorAction SilentlyContinue ){
$exist_ffmpeg = 1
}


$file_txt = @()
$file_txt += Get-ChildItem -file -Include "*.txt" -Name
#echo $file_txt

$d_file_txt = $file_txt.Length -1
#echo $d_file_txt


# neni zadny soubor *.txt v adresary
if ( $d_file_txt -lt 0 ){
Write-Host -ForegroundColor Red "nenalezeny zadne soubory 'txt'"
echo "konec"
sleep 5
exit 1    
}


for ( $aa = 0; $aa -le $d_file_txt; $aa++ ){
$input_text = $file_txt[$aa]                                  
echo $input_text

# nazev vystupniho souboru *.wav
$name_wav = $input_text.Substring(0,$input_text.Length -3)
$name_wav += "wav"
echo $name_wav


# nazev vystupniho souboru *.mp3
if ( $exist_ffmpeg -eq 1 ){
$name_mp3 = $name_wav.Substring(0,$name_wav.Length -3)
$name_mp3 += "mp3"
echo $name_mp3
#ffmpeg -y -i $name_wav -b:a 192k -vol 1024 $name_mp3
#ffmpeg -y -i $name_wav $name_mp3
#Write-Host -ForegroundColor Cyan "text byl ulozen do souboru '$name_mp3'"
}



# postupne nacteni obsahu vsech nalezenych *.txt souboru v aktualnim adresary
Remove-Variable text -ErrorAction SilentlyContinue

$text = Get-Content $input_text -Encoding UTF8 # UTF8 je pro cestinu
#Write-Host -ForegroundColor yellow $text 
# melo by se zobrazit jako cesky text z diakritikou ( paklize ne tak je chyba a *.wav bude rikat kraviny )
echo $text
echo "-----------"
sleep 2
}






                    
<#
-eq ==
-ne !=
-lt <
-gt >
-le <=
-ge >=
#>
                    


















<#
echo "------------------------"
Get-ChildItem -Path $cesta -Include "*.txt", "*doc" -Name
echo "---------------------------------------"
Get-ChildItem -Path $cesta -Include "*.txt", "*doc", "*.bas" -Name # files only no directory

Get-ChildItem -Path $cesta

cls

Get-ChildItem -Directory # jenom adresare

Get-ChildItem -file # jenom soubory

Get-ChildItem # oboji
#>

