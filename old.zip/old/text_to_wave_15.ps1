﻿cls

# prelozi textovej soubor v cestine ( kodovani UTF8 ) do souboru Wav

# cesta k soubu z ceskym textem (UTF8)
$input_text = "text.txt" # nazev, pripadne cela cesta k soubor z ceskym textem

# Načtení textu ze souboru
$text = Get-Content $input_text -Encoding UTF8 # UTF8 je pro cestinu
Write-Host -ForegroundColor yellow $text # melo by se zobrazit joko cesky text z diakritikou ( paklize ne tak je chyba a *.wav bude rikat kraviny )

$name_wav = "audio.wav" # nazev vystupniho souboru wav

# smaze stary soubor wav a mp3
Remove-Item -Path $name_wav -Force -ErrorAction SilentlyContinue
$name_mp3 = $name_wav.Substring(0,$name_wav.Length -3)
$name_mp3 += "mp3"
#echo $name_mp3
Remove-Item -Path $name_mp3 -Force -ErrorAction SilentlyContinue

#
Add-Type -AssemblyName System.Speech
$synth = New-Object -TypeName System.Speech.Synthesis.SpeechSynthesizer

$hlasy = $synth.GetInstalledVoices() | Select-Object -ExpandProperty VoiceInfo # dela vypis hlasu
$d_hlasy = $hlasy.Length -1
#echo $d_hlasy

<#
for ($aa = 0; $aa -le $d_hlasy; $aa++) {
$out_1 = ""
$out_1 += [string] $aa
$out_1 += " - "
$out_1 += $hlasy[$aa].Name
$out_1 += " - "
$out_1 += $hlasy[$aa].Culture.Name
echo $out_1
}

$out_2 = "vyber hlas 0-"
$out_2 += [string] $d_hlasy
$out_2 += " ?"
[int] $volba = Read-Host -Prompt $out_2
#echo $volba
#>

# nejdou otevrit hlasy ktery maj na konci privlastek "Desktop", nezjisteno proc
# napr. misto hlasu "Microsoft Irina Desktop" vybrat ze seznamu "Microsoft Irina" a pak to funguje


# prepsani nalezenich nazvu hlasu do noveho pole z vynechanim vsech co maj na konci "Desktop"
$pole_hlasy_2 = @()

for ($bb = 0; $bb -le $d_hlasy; $bb++) {

[string] $hlas = $hlasy[$bb].name
echo $hlas[$bb].Culture.Name
#echo $hlas
$test = $hlas.IndexOf("Desktop") # nanajde = -1
#echo $test #int32

if ($test -eq -1) {
echo $hlas
$pole_hlasy_2 += $hlas
}
#$hlasy[$bb].name                                     
#echo $bb
} 





exit

#$synth.SelectVoice($hlasy[$volba].Name)
#$synth.SelectVoice("Microsoft Jakub")
#$synth.SelectVoice("Microsoft Hortense")

# Nastavení hlasitosti a rychlosti
$synth.Volume = 100 # hlasitost 0-100 
$synth.Rate = 0 # -10 az 10 ( 0 = normalni rychlost mluveni )

#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(8000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono)
$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Stereo)
#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono)

$synth.SetOutputToWaveFile($name_wav, $streamFormat)

#$synth.SetOutputToWaveFile("C:\Users\DELL\Documents\ps1\Sound-Speech-PlayWav\speech_to_wave\$name.wav", $streamFormat )
$synth.SetOutputToWaveFile($name_wav, $streamFormat )

$synth.Speak($text)
$synth.Dispose() # uzavreni streamu

echo "text byl ulozen do souboru '$name_wav'"

# prevod z WAV doMP3 pomocí ffmpeg ( pokud je pritomny )
#ffmpeg -y -i $name_wav -b:a 192k -vol 1024 $name_mp3
#ffmpeg -y -i $name_wav $name_mp3

# sleep 5

