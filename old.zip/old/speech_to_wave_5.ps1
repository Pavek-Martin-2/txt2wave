﻿cls

Add-Type -AssemblyName System.Speech

$name = "output_1"


$input = "Ve Windows 10 jsou některé hlasy předinstalované, jiné je potřeba doinstalovat přes" #, "pondely"


#foreach ($name in $input) {
$speak = New-Object -TypeName System.Speech.Synthesis.SpeechSynthesizer

#$speak.SelectVoice("Microsoft David Desktop")

$speak.SelectVoice("Microsoft Jakub")

#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(8000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono)

$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Stereo)

$speak.SetOutputToWaveFile("$name.wav", $streamFormat)

#$speak.SetOutputToWaveFile("C:\Users\DELL\Documents\ps1\Sound-Speech-PlayWav\speech_to_wave\$name.wav")

$speak.SetOutputToWaveFile("$name.wav", $streamFormat )

$speak.Speak($input)

$speak.Dispose()






