﻿cls

Add-Type -AssemblyName System.Speech

$name = "1"


$input = "Name One", "Name Two", "Name Tree"


foreach ($name in $input) {
$speak = New-Object -TypeName System.Speech.Synthesis.SpeechSynthesizer

#$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]
$streamFormat = [System.Speech.AudioFormat.SpeechAudioFormatInfo]

#$speak.SetOutputToWaveFile("C:\work\$name.wav", $streamFormat)
$speak.SetOutputToWaveFile("$PWD$name.wav")

$speak.Speak($name)
$speak.Dispose()

}




